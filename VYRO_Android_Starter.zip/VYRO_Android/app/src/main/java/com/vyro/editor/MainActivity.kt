package com.vyro.editor

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

private val Bg = Color(0xFF070B14)
private val Card = Color(0xFF121827)
private val Purple = Color(0xFF7658FF)
private val Blue = Color(0xFF5AB2FF)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { VyroApp() }
    }
}

@Composable
fun VyroApp() {
    var splash by remember { mutableStateOf(true) }
    if (splash) SplashScreen { splash = false } else HomeScreen()
}

@Composable
fun SplashScreen(onFinished: () -> Unit) {
    val scale = remember { Animatable(0.7f) }
    val alpha = remember { Animatable(0f) }
    val shine = remember { Animatable(-1f) }

    LaunchedEffect(Unit) {
        alpha.animateTo(1f, tween(650))
        scale.animateTo(1f, tween(850, easing = FastOutSlowInEasing))
        shine.animateTo(1.2f, tween(900))
        delay(650)
        onFinished()
    }

    Box(
        modifier = Modifier.fillMaxSize().background(Bg),
        contentAlignment = Alignment.Center
    ) {
        Box(
            modifier = Modifier
                .size(180.dp)
                .scale(scale.value)
                .alpha(alpha.value)
                .background(
                    Brush.linearGradient(
                        listOf(Purple, Blue, Color.White, Purple)
                    ),
                    RoundedCornerShape(42.dp)
                ),
            contentAlignment = Alignment.Center
        ) {
            Text(
                "V",
                fontSize = 110.sp,
                fontWeight = FontWeight.Black,
                color = Bg
            )
        }
        Column(
            modifier = Modifier
                .align(Alignment.Center)
                .padding(top = 280.dp)
                .alpha(alpha.value),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text("VYRO", color = Color.White, fontSize = 34.sp, fontWeight = FontWeight.Bold, letterSpacing = 8.sp)
            Text("CREATE BEYOND LIMITS.", color = Color(0xFFB5BED2), fontSize = 11.sp, letterSpacing = 3.sp)
        }
    }
}

@Composable
fun HomeScreen() {
    var editor by remember { mutableStateOf(false) }
    if (editor) EditorScreen { editor = false } else {
        Scaffold(
            containerColor = Bg,
            bottomBar = {
                NavigationBar(containerColor = Color(0xFF0B101C)) {
                    listOf(
                        Icons.Default.Home to "Home",
                        Icons.Default.Folder to "Projects",
                        Icons.Default.AutoAwesome to "Effects",
                        Icons.Default.Person to "Profile"
                    ).forEachIndexed { i, item ->
                        NavigationBarItem(
                            selected = i == 0,
                            onClick = {},
                            icon = { Icon(item.first, item.second) },
                            label = { Text(item.second) }
                        )
                    }
                }
            }
        ) { padding ->
            Column(
                modifier = Modifier.fillMaxSize().padding(padding).padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(18.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("VYRO", color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Bold, letterSpacing = 4.sp)
                    Spacer(Modifier.weight(1f))
                    Icon(Icons.Default.Settings, null, tint = Color(0xFFB7C0D4))
                }

                Card(
                    modifier = Modifier.fillMaxWidth().height(130.dp).clickable { editor = true },
                    shape = RoundedCornerShape(24.dp),
                    colors = CardDefaults.cardColors(containerColor = Card)
                ) {
                    Row(
                        modifier = Modifier.fillMaxSize().padding(24.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            Modifier.size(62.dp).background(
                                Brush.linearGradient(listOf(Purple, Blue)),
                                RoundedCornerShape(22.dp)
                            ),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.Add, null, tint = Color.White, modifier = Modifier.size(36.dp))
                        }
                        Spacer(Modifier.width(18.dp))
                        Column {
                            Text("New Project", color = Color.White, fontSize = 23.sp, fontWeight = FontWeight.Bold)
                            Text("Start editing your magic", color = Color(0xFFB7C0D4))
                        }
                    }
                }

                Text("Quick Actions", color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.Bold)
                val actions = listOf(
                    Icons.Default.AutoFixHigh to "Auto Cut",
                    Icons.Default.Layers to "Overlay",
                    Icons.Default.ContentCut to "Split",
                    Icons.Default.AutoAwesome to "Effects",
                    Icons.Default.Filter to "Filters",
                    Icons.Default.TextFields to "Text"
                )
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    actions.chunked(3).forEach { row ->
                        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            row.forEach { action ->
                                Card(
                                    modifier = Modifier.weight(1f).height(104.dp),
                                    shape = RoundedCornerShape(20.dp),
                                    colors = CardDefaults.cardColors(containerColor = Card)
                                ) {
                                    Column(
                                        modifier = Modifier.fillMaxSize(),
                                        verticalArrangement = Arrangement.Center,
                                        horizontalAlignment = Alignment.CenterHorizontally
                                    ) {
                                        Icon(action.first, action.second, tint = Color(0xFFB9C4E8), modifier = Modifier.size(30.dp))
                                        Spacer(Modifier.height(8.dp))
                                        Text(action.second, color = Color.White, fontSize = 12.sp)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun EditorScreen(onBack: () -> Unit) {
    var selected by remember { mutableStateOf("Video") }

    Scaffold(
        containerColor = Bg,
        topBar = {
            TopAppBar(
                title = { Text("New Project", color = Color.White) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, null, tint = Color.White)
                    }
                },
                actions = {
                    TextButton(onClick = {}) { Text("Export", color = Blue, fontWeight = FontWeight.Bold) }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Bg)
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier.fillMaxSize().padding(padding).padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(240.dp)
                    .background(
                        Brush.verticalGradient(listOf(Color(0xFF1C3150), Color(0xFF0B0F19))),
                        RoundedCornerShape(18.dp)
                    ),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Default.PlayCircle, null, tint = Color.White, modifier = Modifier.size(64.dp))
                    Text("Video Preview", color = Color.White, fontSize = 18.sp)
                    Text("00:07 / 00:32", color = Color(0xFFB7C0D4))
                }
            }

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("Video", "Audio", "Speed", "Animation").forEach { item ->
                    FilterChip(
                        selected = selected == item,
                        onClick = { selected = item },
                        label = { Text(item) }
                    )
                }
            }

            Text("Timeline", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp)
            repeat(4) { index ->
                Card(
                    modifier = Modifier.fillMaxWidth().height(if (index == 0) 62.dp else 44.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = when (index) {
                            0 -> Color(0xFF253B72)
                            1 -> Color(0xFF543A84)
                            2 -> Color(0xFF23615E)
                            else -> Color(0xFF173D70)
                        }
                    ),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxSize().padding(horizontal = 14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            when (index) {
                                0 -> Icons.Default.VideoLibrary
                                1 -> Icons.Default.Layers
                                2 -> Icons.Default.TextFields
                                else -> Icons.Default.MusicNote
                            },
                            null,
                            tint = Color.White
                        )
                        Spacer(Modifier.width(10.dp))
                        Text(
                            listOf("Main Video", "Overlay", "Text: Better Days Ahead", "Music Track")[index],
                            color = Color.White
                        )
                    }
                }
            }

            Spacer(Modifier.weight(1f))
            Row(horizontalArrangement = Arrangement.SpaceEvenly, modifier = Modifier.fillMaxWidth()) {
                listOf(
                    Icons.Default.ContentCut to "Split",
                    Icons.Default.Delete to "Delete",
                    Icons.Default.Copy to "Duplicate",
                    Icons.Default.Layers to "Layers"
                ).forEach { tool ->
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        IconButton(onClick = {}) {
                            Icon(tool.first, tool.second, tint = Color(0xFFC1CAE0))
                        }
                        Text(tool.second, color = Color(0xFFB7C0D4), fontSize = 10.sp)
                    }
                }
            }
        }
    }
}
